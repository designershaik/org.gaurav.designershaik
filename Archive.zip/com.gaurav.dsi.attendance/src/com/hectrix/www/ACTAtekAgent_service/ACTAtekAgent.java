/**
 * ACTAtekAgent.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.hectrix.www.ACTAtekAgent_service;

public interface ACTAtekAgent extends javax.xml.rpc.Service {

/**
 * WebService API for ACTAtek Agent
 */
    public java.lang.String getACTAtekAgentAddress();

    public com.hectrix.www.ACTAtekAgent_service.ACTAtekAgentPortType getACTAtekAgent() throws javax.xml.rpc.ServiceException;

    public com.hectrix.www.ACTAtekAgent_service.ACTAtekAgentPortType getACTAtekAgent(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
