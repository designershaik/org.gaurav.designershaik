/**
 * FingerprintHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.hectrix.www.ACTAtek_xsd.holders;

public final class FingerprintHolder implements javax.xml.rpc.holders.Holder {
    public com.hectrix.www.ACTAtek_xsd.Fingerprint value;

    public FingerprintHolder() {
    }

    public FingerprintHolder(com.hectrix.www.ACTAtek_xsd.Fingerprint value) {
        this.value = value;
    }

}
