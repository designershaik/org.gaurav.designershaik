/******************************************************************************
 * Product: iDempiere ERP & CRM Smart Business Solution                       *
 * Copyright (C) 1999-2012 ComPiere, Inc. All Rights Reserved.                *
 * This program is free software, you can redistribute it and/or modify it    *
 * under the terms version 2 of the GNU General Public License as published   *
 * by the Free Software Foundation. This program is distributed in the hope   *
 * that it will be useful, but WITHOUT ANY WARRANTY, without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.           *
 * See the GNU General Public License for more details.                       *
 * You should have received a copy of the GNU General Public License along    *
 * with this program, if not, write to the Free Software Foundation, Inc.,    *
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.                     *
 * For the text or an alternative of this public license, you may reach us    *
 * ComPiere, Inc., 2620 Augustine Dr. #245, Santa Clara, CA 95054, USA        *
 * or via info@compiere.org or http://www.compiere.org/license.html           *
 *****************************************************************************/
/** Generated Model - DO NOT CHANGE */
package org.gaurav.dsi.model;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.Properties;
import org.compiere.model.*;
import org.compiere.util.Env;

/** Generated Model for DS_FinReports_level3
 *  @author iDempiere (generated) 
 *  @version Release 4.1 - $Id$ */
public class X_DS_FinReports_level3 extends PO implements I_DS_FinReports_level3, I_Persistent 
{

	/**
	 *
	 */
	private static final long serialVersionUID = 20180106L;

    /** Standard Constructor */
    public X_DS_FinReports_level3 (Properties ctx, int DS_FinReports_level3_ID, String trxName)
    {
      super (ctx, DS_FinReports_level3_ID, trxName);
      /** if (DS_FinReports_level3_ID == 0)
        {
			setDS_FinReports_level3_ID (0);
        } */
    }

    /** Load Constructor */
    public X_DS_FinReports_level3 (Properties ctx, ResultSet rs, String trxName)
    {
      super (ctx, rs, trxName);
    }

    /** AccessLevel
      * @return 3 - Client - Org 
      */
    protected int get_AccessLevel()
    {
      return accessLevel.intValue();
    }

    /** Load Meta Data */
    protected POInfo initPO (Properties ctx)
    {
      POInfo poi = POInfo.getPOInfo (ctx, Table_ID, get_TrxName());
      return poi;
    }

    public String toString()
    {
      StringBuffer sb = new StringBuffer ("X_DS_FinReports_level3[")
        .append(get_ID()).append("]");
      return sb.toString();
    }

	/** AccountType AD_Reference_ID=117 */
	public static final int ACCOUNTTYPE_AD_Reference_ID=117;
	/** Asset = A */
	public static final String ACCOUNTTYPE_Asset = "A";
	/** Liability = L */
	public static final String ACCOUNTTYPE_Liability = "L";
	/** Revenue = R */
	public static final String ACCOUNTTYPE_Revenue = "R";
	/** Expense = E */
	public static final String ACCOUNTTYPE_Expense = "E";
	/** Owner's Equity = O */
	public static final String ACCOUNTTYPE_OwnerSEquity = "O";
	/** Memo = M */
	public static final String ACCOUNTTYPE_Memo = "M";
	/** Set Account Type.
		@param AccountType 
		Indicates the type of account
	  */
	public void setAccountType (String AccountType)
	{

		set_ValueNoCheck (COLUMNNAME_AccountType, AccountType);
	}

	/** Get Account Type.
		@return Indicates the type of account
	  */
	public String getAccountType () 
	{
		return (String)get_Value(COLUMNNAME_AccountType);
	}

	/** Set Source Credit.
		@param AmtSourceCr 
		Source Credit Amount
	  */
	public void setAmtSourceCr (BigDecimal AmtSourceCr)
	{
		set_ValueNoCheck (COLUMNNAME_AmtSourceCr, AmtSourceCr);
	}

	/** Get Source Credit.
		@return Source Credit Amount
	  */
	public BigDecimal getAmtSourceCr () 
	{
		BigDecimal bd = (BigDecimal)get_Value(COLUMNNAME_AmtSourceCr);
		if (bd == null)
			 return Env.ZERO;
		return bd;
	}

	/** Set Source Debit.
		@param AmtSourceDr 
		Source Debit Amount
	  */
	public void setAmtSourceDr (BigDecimal AmtSourceDr)
	{
		set_ValueNoCheck (COLUMNNAME_AmtSourceDr, AmtSourceDr);
	}

	/** Get Source Debit.
		@return Source Debit Amount
	  */
	public BigDecimal getAmtSourceDr () 
	{
		BigDecimal bd = (BigDecimal)get_Value(COLUMNNAME_AmtSourceDr);
		if (bd == null)
			 return Env.ZERO;
		return bd;
	}

	/** Set Balance.
		@param Balance Balance	  */
	public void setBalance (BigDecimal Balance)
	{
		set_ValueNoCheck (COLUMNNAME_Balance, Balance);
	}

	/** Get Balance.
		@return Balance	  */
	public BigDecimal getBalance () 
	{
		BigDecimal bd = (BigDecimal)get_Value(COLUMNNAME_Balance);
		if (bd == null)
			 return Env.ZERO;
		return bd;
	}

	public org.compiere.model.I_C_ElementValue getC_ElementValue() throws RuntimeException
    {
		return (org.compiere.model.I_C_ElementValue)MTable.get(getCtx(), org.compiere.model.I_C_ElementValue.Table_Name)
			.getPO(getC_ElementValue_ID(), get_TrxName());	}

	/** Set Account Element.
		@param C_ElementValue_ID 
		Account Element
	  */
	public void setC_ElementValue_ID (int C_ElementValue_ID)
	{
		if (C_ElementValue_ID < 1) 
			set_Value (COLUMNNAME_C_ElementValue_ID, null);
		else 
			set_Value (COLUMNNAME_C_ElementValue_ID, Integer.valueOf(C_ElementValue_ID));
	}

	/** Get Account Element.
		@return Account Element
	  */
	public int getC_ElementValue_ID () 
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_C_ElementValue_ID);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}

	/** Set Description.
		@param Description 
		Optional short description of the record
	  */
	public void setDescription (String Description)
	{
		set_Value (COLUMNNAME_Description, Description);
	}

	/** Get Description.
		@return Optional short description of the record
	  */
	public String getDescription () 
	{
		return (String)get_Value(COLUMNNAME_Description);
	}

	public I_DS_FinReports_level2 getDS_FinReports_level2() throws RuntimeException
    {
		return (I_DS_FinReports_level2)MTable.get(getCtx(), I_DS_FinReports_level2.Table_Name)
			.getPO(getDS_FinReports_level2_ID(), get_TrxName());	}

	/** Set Finance Reports Level2.
		@param DS_FinReports_level2_ID Finance Reports Level2	  */
	public void setDS_FinReports_level2_ID (int DS_FinReports_level2_ID)
	{
		if (DS_FinReports_level2_ID < 1) 
			set_ValueNoCheck (COLUMNNAME_DS_FinReports_level2_ID, null);
		else 
			set_ValueNoCheck (COLUMNNAME_DS_FinReports_level2_ID, Integer.valueOf(DS_FinReports_level2_ID));
	}

	/** Get Finance Reports Level2.
		@return Finance Reports Level2	  */
	public int getDS_FinReports_level2_ID () 
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_DS_FinReports_level2_ID);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}

	/** Set Finance Reports Level3.
		@param DS_FinReports_level3_ID Finance Reports Level3	  */
	public void setDS_FinReports_level3_ID (int DS_FinReports_level3_ID)
	{
		if (DS_FinReports_level3_ID < 1) 
			set_ValueNoCheck (COLUMNNAME_DS_FinReports_level3_ID, null);
		else 
			set_ValueNoCheck (COLUMNNAME_DS_FinReports_level3_ID, Integer.valueOf(DS_FinReports_level3_ID));
	}

	/** Get Finance Reports Level3.
		@return Finance Reports Level3	  */
	public int getDS_FinReports_level3_ID () 
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_DS_FinReports_level3_ID);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}

	/** Set DS_FinReports_level3_UU.
		@param DS_FinReports_level3_UU DS_FinReports_level3_UU	  */
	public void setDS_FinReports_level3_UU (String DS_FinReports_level3_UU)
	{
		set_Value (COLUMNNAME_DS_FinReports_level3_UU, DS_FinReports_level3_UU);
	}

	/** Get DS_FinReports_level3_UU.
		@return DS_FinReports_level3_UU	  */
	public String getDS_FinReports_level3_UU () 
	{
		return (String)get_Value(COLUMNNAME_DS_FinReports_level3_UU);
	}

	/** Set Summary Level.
		@param IsSummary 
		This is a summary entity
	  */
	public void setIsSummary (boolean IsSummary)
	{
		set_Value (COLUMNNAME_IsSummary, Boolean.valueOf(IsSummary));
	}

	/** Get Summary Level.
		@return This is a summary entity
	  */
	public boolean isSummary () 
	{
		Object oo = get_Value(COLUMNNAME_IsSummary);
		if (oo != null) 
		{
			 if (oo instanceof Boolean) 
				 return ((Boolean)oo).booleanValue(); 
			return "Y".equals(oo);
		}
		return false;
	}

	/** Set Name.
		@param Name 
		Alphanumeric identifier of the entity
	  */
	public void setName (String Name)
	{
		set_Value (COLUMNNAME_Name, Name);
	}

	/** Get Name.
		@return Alphanumeric identifier of the entity
	  */
	public String getName () 
	{
		return (String)get_Value(COLUMNNAME_Name);
	}

	/** Set Sequence.
		@param SeqNo 
		Method of ordering records; lowest number comes first
	  */
	public void setSeqNo (int SeqNo)
	{
		set_Value (COLUMNNAME_SeqNo, Integer.valueOf(SeqNo));
	}

	/** Get Sequence.
		@return Method of ordering records; lowest number comes first
	  */
	public int getSeqNo () 
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_SeqNo);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}

	/** Set Total Credit.
		@param TotalCr 
		Total Credit in document currency
	  */
	public void setTotalCr (BigDecimal TotalCr)
	{
		set_ValueNoCheck (COLUMNNAME_TotalCr, TotalCr);
	}

	/** Get Total Credit.
		@return Total Credit in document currency
	  */
	public BigDecimal getTotalCr () 
	{
		BigDecimal bd = (BigDecimal)get_Value(COLUMNNAME_TotalCr);
		if (bd == null)
			 return Env.ZERO;
		return bd;
	}

	/** Set Total Debit.
		@param TotalDr 
		Total debit in document currency
	  */
	public void setTotalDr (BigDecimal TotalDr)
	{
		set_ValueNoCheck (COLUMNNAME_TotalDr, TotalDr);
	}

	/** Get Total Debit.
		@return Total debit in document currency
	  */
	public BigDecimal getTotalDr () 
	{
		BigDecimal bd = (BigDecimal)get_Value(COLUMNNAME_TotalDr);
		if (bd == null)
			 return Env.ZERO;
		return bd;
	}
}