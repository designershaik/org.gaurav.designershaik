package org.gaurav.dsi.model;

import java.sql.ResultSet;
import java.util.Properties;

public class MDSIBoxLabelsT extends X_DSI_BoxLabels_T {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MDSIBoxLabelsT(Properties ctx, int DSI_BoxLabels_T_ID, String trxName) {
		super(ctx, DSI_BoxLabels_T_ID, trxName);
		// TODO Auto-generated constructor stub
	}

	public MDSIBoxLabelsT(Properties ctx, ResultSet rs, String trxName) {
		super(ctx, rs, trxName);
		// TODO Auto-generated constructor stub
	}

}
