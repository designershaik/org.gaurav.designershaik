package org.gaurav.dsi.model;

import java.sql.ResultSet;
import java.util.Properties;

public class MDSFinReportslevel6 extends X_DS_FinReports_level6 {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3656106238831361563L;

	/**
	 * 
	 */

	public MDSFinReportslevel6(Properties ctx, ResultSet rs, String trxName)
	{
		super(ctx, rs, trxName);
		// TODO Auto-generated constructor stub
	}

	public MDSFinReportslevel6(Properties ctx, int DS_FinReports_level6_ID,
			String trxName) {
		super(ctx, DS_FinReports_level6_ID, trxName);
		// TODO Auto-generated constructor stub
	}

}
